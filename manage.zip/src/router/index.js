import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '../views/HelloWorld'
import Login from '../views/Login'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/test',
      component: HelloWorld,
      children: [
        {
          path: '/home',
          component: HelloWorld,
          meta: {
            title: '系统首页'
          }
        }
      ]
    },
    {
      path: '/login',
      component: Login,
      meta: {
        title: '登陆'
      }
    }
  ]
})

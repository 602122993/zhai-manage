<template>
  <div class="mavonEditor">
    <p>ttttttttttttt</p>
  </div>
</template>
<script>
export default {
  data() {
    return {
      markdownOption: {
        bold: true // 粗体
      },
      handbook: "![](http://images.xiaoazhai.com/blog/timg.jpg)"
    };
  },
  methods: {
    getHashParams(url) {
      return querystring.parse(url.split("?")[1] || "{}");
    },
    fixHashUrlAndJump(pathname) {
      if (location.href.includes(`${pathname}/?code`)) {
        let href = location.href;
        let url = href.substring(0, href.length - 2);
        console.log(href,url)
        let jingPosit = url.indexOf(`${pathname}/`) + pathname.length + 1;
        let urlLeft = url.substring(0, jingPosit);
        let urlRight = url.substring(jingPosit, url.length);
        // location.href = urlLeft + "#/" + urlRight;
        return true;
      } else {
        return false;
      }
    }
  },
  created() {
    if (this.fixHashUrlAndJump("test")) {
      console.log(this.getHashParams(location.href));
    }
  }
};
</script>

<style scoped>
.mavonEditor {
  width: 100%;
  height: 100%;
}
</style>